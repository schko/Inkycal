#ifndef _TEST_H_
#define _TEST_H_

#include <stdlib.h>     //exit()
#include <signal.h>     //signal()
#include <time.h>
#include "GUI_Paint.h"
#include "GUI_BMPfile.h"


int EPD_12in48_test(void);
int EPD_12in48B_test(void);
#endif